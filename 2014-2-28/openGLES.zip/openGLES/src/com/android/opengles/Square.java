package com.android.opengles;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import javax.microedition.khronos.opengles.GL10;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.util.Log;

public class Square {

	
private float vertices[] = {
		 -1.0f,  1.0f, 0.0f,  // 0, Top Left
		 -1.0f, -1.0f, 0.0f,  // 1, Bottom Left
		 1.0f, -1.0f, 0.0f,  // 2, Bottom Right
		 1.0f,  1.0f, 0.0f,  // 3, Top Right
 		};
  
 // The order we like to connect them.
private short[] indices = { 0, 1, 2, 0, 2, 3 };
  
 // Our vertex buffer.
private FloatBuffer vertexBuffer;
private FloatBuffer colorBuffer;
  
 // Our index buffer.
private ShortBuffer indexBuffer;
  
public Square() {
	 // a float is 4 bytes, therefore we
	 // multiply the number if
	 // vertices with 4.
	 ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
	 vbb.order(ByteOrder.nativeOrder());
	 vertexBuffer = vbb.asFloatBuffer();
	 vertexBuffer.put(vertices);
	 vertexBuffer.position(0);
  
	 // short is 2 bytes, therefore we multiply
	 //the number if
	 // vertices with 2.
	 ByteBuffer ibb = ByteBuffer.allocateDirect(indices.length * 2);
	 ibb.order(ByteOrder.nativeOrder());
	 indexBuffer = ibb.asShortBuffer();
	 indexBuffer.put(indices);
	 indexBuffer.position(0);
 
 
 
float[] colors = {
			 1f, 0f, 0f, 1f, // vertex 0 red
			 0f, 1f, 0f, 1f, // vertex 1 green
			 0f, 0f, 1f, 1f, // vertex 2 blue
			 1f, 0f, 1f, 1f, // vertex 3 magenta
		};

// float has 4 bytes, colors (RGBA) * 4 bytes
			ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
			cbb.order(ByteOrder.nativeOrder());
			colorBuffer = cbb.asFloatBuffer();
			colorBuffer.put(colors);
			colorBuffer.position(0);

 }
  
 /**
 * This function draws our square on screen.
 * @param gl
 */
 public void draw(GL10 gl) {
			 // Counter-clockwise winding.
			 gl.glFrontFace(GL10.GL_CCW);
			 // Enable face culling.
			 gl.glEnable(GL10.GL_CULL_FACE);
			 // What faces to remove with the face culling.
			 gl.glCullFace(GL10.GL_BACK);
			  
			 // Enabled the vertices buffer for writing
			 //and to be used during
			 // rendering.
			 gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
			 // Specifies the location and data format of
			 //an array of vertex
			 // coordinates to use when rendering.
			 gl.glVertexPointer(3, GL10.GL_FLOAT, 0,
			 vertexBuffer);
			  
			 gl.glDrawElements(GL10.GL_TRIANGLES, indices.length,
			 GL10.GL_UNSIGNED_SHORT, indexBuffer);
			  
			 // Disable the vertices buffer.
			 gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
			 // Disable face culling.
			 gl.glDisable(GL10.GL_CULL_FACE);
			 
			 
			 
			//			 gl.glColor4f(0.5f, 0.5f, 1.0f, 1.0f);
			 
			gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
			  
			// Enable the color array buffer to be
			//used during rendering.
			gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
			// Point out the where the color buffer is.
			gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuffer);	
			
			Log.i("OpenGl Es", "into save");
			
			 try {
				SavePNG(0, 0, 400, 600, "cwj.png", gl);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		  
			Log.i("OpenGl Es", "saved");
				
				gl.glDisableClientState(GL10.GL_COLOR_ARRAY);
			
				 
				 
			 
 }
 
 
    public static void SavePNG(int x, int y, int w, int h, String fileName, GL10 gl) throws IOException
    {
    	Bitmap bmp=SavePixels(x,y,w,h,gl);
		File file = new File("/mnt/sdcard/QQ_Screenshot/");
		if (!file.exists()) {
			Log.i("OpenGl Es", "not exist");
			file.mkdirs();
		}
			File imageFile = new File(file, System.currentTimeMillis() +".png");
		FileOutputStream fos = new FileOutputStream(imageFile);
		Log.i("OpenGl Es", "out put file");
		bmp.compress(CompressFormat.JPEG, 50, fos);
		Log.i("OpenGl Es", "format");
					fos.flush();
					fos.close();
}
	
	
	
    public static byte[] bmpToByteArray(Bitmap bmp){  
        //Default size is 32 bytes  
        ByteArrayOutputStream bos = new ByteArrayOutputStream();  
        try {  
	       bmp.compress(Bitmap.CompressFormat.JPEG, 100, bos);  
	       bos.close();  
	     } catch (IOException e) {  
	        e.printStackTrace();  
	       }  
	    return bos.toByteArray();  
	    }  				
		
	
	
	
	
	
 public static Bitmap SavePixels(int x, int y, int w, int h, GL10 gl)
 { 
	int b[]=new int[w*h];
	int bt[]=new int[w*h];
	IntBuffer ib=IntBuffer.wrap(b);
	ib.position(0);
	Log.i("OpenGl Es", "readpixels");
	
	gl.glReadPixels(x, y, w, h, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, ib);
	Log.i("OpenGl Es", "readpixels ed");
	
	for(int i=0; i<h; i++)
		{ 
		for(int j=0; j<w; j++)
		{
		int pix=b[i*w+j];
		int pb=(pix>>16)&0xff;
		int pr=(pix<<16)&0x00ff0000;
		int pix1=(pix&0xff00ff00) | pr | pb;
		bt[(h-i-1)*w+j]=pix1;
		}
		}
	Log.i("OpenGl Es", "createbitmap");
	
	Bitmap sb=Bitmap.createBitmap(bt, w, h, Bitmap.Config.ARGB_8888);
	Log.i("OpenGl Es", "bitmaped");

		return sb;
		}
	
}






