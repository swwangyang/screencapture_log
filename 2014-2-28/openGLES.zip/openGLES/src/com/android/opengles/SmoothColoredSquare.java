package com.android.opengles;

import javax.microedition.khronos.opengles.GL10;

public class SmoothColoredSquare extends Square {
	public void draw(GL10 gl) {

	super.draw(gl);
	
	}
	
}
